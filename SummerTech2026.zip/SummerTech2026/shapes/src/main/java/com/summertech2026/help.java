package com.summertech2026;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.PerspectiveCamera;
import javafx.scene.Scene;
import javafx.scene.SceneAntialiasing;
import javafx.scene.paint.Color;
import javafx.scene.transform.Rotate;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;
import org.fxyz3d.shapes.primitives.Text3DMesh;

public class help extends Application {

    private double mousePosX, mousePosY, mouseOldX, mouseOldY;
    private final Rotate rotateX = new Rotate(20, Rotate.X_AXIS);
    private final Rotate rotateY = new Rotate(-20, Rotate.Y_AXIS);

    @Override
    public void start(Stage primaryStage) {
        // Create 3D text using FXyz
        Text3DMesh textMesh = new Text3DMesh("Hello FXyz!");
        textMesh.setFontSize(50);
        
        // Wrap with a material texture mapping (mandatory for rendering visibility in FXyz)
        textMesh.setTextureModeVertices3D(1530, p -> p.x); 
        //textMesh.setFill(Color.CORNFLOWERBLUE);

        // Center the text
        textMesh.setTranslateX(-200);
        textMesh.setTranslateY(-25);

        // Set up camera and transforms
        PerspectiveCamera camera = new PerspectiveCamera(true);
        camera.setNearClip(0.1);
        camera.setFarClip(10000.0);
        camera.getTransforms().addAll(rotateX, rotateY, new Translate(0, 0, -800));

        // Group the 3D text
        Group root = new Group(textMesh);

        // Scene setup
        Scene scene = new Scene(root, 800, 600, true, SceneAntialiasing.BALANCED);
        scene.setFill(Color.WHITESMOKE);
        scene.setCamera(camera);

        // // Mouse controls to rotate the 3D scene
        // scene.setOnMousePressed(event -> {
        //     mousePosX = event.getSceneX();
        //     mousePosY = event.getSceneY();
        // });

        // scene.setOnMouseDragged(event -> {
        //     mouseOldX = mousePosX;
        //     mouseOldY = mousePosY;
        //     mousePosX = event.getSceneX();
        //     mousePosY = event.getSceneY();
            
        //     rotateX.setAngle(rotateX.getAngle() - (mousePosY - mouseOldY));
        //     rotateY.setAngle(rotateY.getAngle() + (mousePosX - mouseOldX));
        // });

        primaryStage.setTitle("FXyz3D 3D Text Example");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
