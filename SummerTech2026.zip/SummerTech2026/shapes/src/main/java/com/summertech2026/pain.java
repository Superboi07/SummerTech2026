package com.summertech2026;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.fxyz3d.shapes.primitives.SpringMesh;

public class pain extends Application {
    @Override
    public void start(Stage stage) {
        SpringMesh spring = new SpringMesh(10, 2, 2, 8 * 2 * Math.PI, 200, 100, 0, 0);
        Scene scene = new Scene(new javafx.scene.Group(spring), 800, 600, true);
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}
